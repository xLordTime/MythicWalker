# Third-party notices

WizWalker — Wizard101 scripting library.
Original author as declared by upstream: StarrFox. DE/EU fork: Vindaloniak. Deimos-maintained upstream: Deimos-Wizard101.
License declared in upstream pyproject.toml: GPL-3.0-or-later.
Source used: https://github.com/Vindaloniak/wizwalker/tree/13223e0911578e586975ace496d9f586ac4538da
The full GPL license text is included in LICENSE. WizWalker is installed as a dependency, rather than copied into this repository.

Bridge dependencies: aiohttp (Apache-2.0), cryptography (Apache-2.0 or BSD-3-Clause). Their transitive dependencies retain their own notices in the installed packages. PyInstaller is only used for optional Windows packaging; its distribution and bootloader license applies to those builds.

Other repositories named in README and sources.json were examined as references or found in repository search. Their code is not incorporated into this project.

## Adapted Deimos navmap implementation

`bridge/navmap.py` is adapted from `Deimos-Wizard101/Deimos-Wizard101`,
`src/teleport_math.py`, commit `d7ef56eb51c5b5316cadba40ca554ec442a5dcee`, GPL-3.0.
The embedded nav parser originated from PeechezNCreem/navwiz and retains its
complete Boost Software License 1.0 notice in that file. Changes isolate the
WizWalker adapter, bound operations, and limit the final walk distance.

## Deimos bot registry and NPC behavior reference

`dist/upstream-bots.json` and its EXE copy bundle unchanged scripts from Deimos-Wizard101/bots, commit `dc5198b1a8570fa169c45fdd2c01768b5da757e0`, licensed GPL-3.0. Fork: https://github.com/xLordTime/bots. Original author metadata and source paths are preserved. Full upstream license text: `dist/BOTS_LICENSE.txt`. The MythicWalker example and default blocks are additional GPL-3.0 project content.

The read-only hostile NPCBehavior flag used by `closest_mob` follows `src/sprinty_client.py` in Deimos-Wizard101/Deimos-Wizard101 (GPL-3.0; SprintyClient credits Sirolaf). No full Deimos VM or Playstyle parser is bundled.

## Deimos Expertmode compiler

`bridge/deimoslang/{tokenizer,types,parser,sem,ir}.py` are copied from Deimos-Wizard101/Deimos-Wizard101 at `d7ef56eb51c5b5316cadba40ca554ec442a5dcee` (GPL-3.0). `expression_vm.py` adapts its expression evaluator; `expert.py` supplies MythicWalker game adapters and a bounded instruction VM. The original desktop UI, account launcher, Python execution and external game extension suite are not bundled. Project license is included as LICENSE. Wiki source was inspected at wiki commit `a165c81b7d2177c4b5cef474f5b557280d2fbf1f`.

## FishBot DE

Vollständiger Originalkern aus https://github.com/xLordTime/Fisch-Bot-DE/blob/c29dc5e183756b5409bd97ad5d776e9c01b73b15/FishBot_Updated_2026.py (Repository des Projektbesitzers), unter `bridge/vendor/fishbot_de.py`.

Der Kern enthält alle originalen Funktionen einschließlich Speedhack, 31 Angel-Patches und Korbleerung. Einzige Änderung in dieser Datei: Bei deaktiviertem SKIP_CAUGHT_FISH_POPUP wird dessen Patch ausgelassen. Web-Konfiguration, Bridge-Anbindung und verifizierte Wiederherstellung liegen separat in `bridge/fishing.py`.

## memobj 0.17.0

Unveränderte Python-Quelldateien aus dem offiziellen PyPI-Wheel von StarrFox/memobj 0.17.0, unter `bridge/memobj`. MIT-Lizenz: `bridge/memobj/LICENSE` (auch in der EXE enthalten). Die pauschalen neueren Paket-Mindestversionen kollidieren mit dem DE-WizWalker; die vom FishBot genutzten APIs werden mit den vorhandenen regex-/pefile-Versionen getestet, iced-x86 1.21.0 wird explizit installiert.

## Raid Utility Tools / WorldsCollideTP

Source: https://github.com/Lxghtend/raid-utility-tools
Commit: 80d6a8d9f7b604460a1345e53e601a65dd760aaa
Built and maintained by **Lxghtend**. WorldsCollideTP built by **CIick**.
License: GPL-3.0; full license at `bridge/vendor/raids/LICENSE`.

The five utility classes, raid coordinates, entity identifiers and collision teleport are adapted for MythicWalker's web UI and existing selected client. Exact adaptation notes are in `bridge/vendor/raids/UPSTREAM.json`. Upstream GUI, anonymous usage tracking, updater, foreground-client polling and duplicate hook ownership are omitted. NumPy (BSD-3-Clause) and Shapely (BSD-3-Clause; bundled GEOS under LGPL) are included by the Windows packager with their package licensing metadata.

### MythicWalker runtime corrections (Beta 14)

The unchanged pinned DE-WizWalker is adapted at the existing client boundary: `movement_guard.py` restores the collision-event branch bytes captured by MovementTeleportHook and scopes its bypass to one native teleport. The original captured bytes are checked after restoration. `fishing.CoreSession` wraps the original FishBot's fish-list reader and pattern scanner with cooperative polling, bounded reads and dead-process handling; fishing behavior and patch definitions remain in the credited original core.

## Wiz Q Launcher integration (MIT)

Source: https://github.com/xLordTime/wiz-q-launcher/tree/bf3759d89bdd4682f09df9999792d8c930c5b7a7

`bridge/launcher_vault.py` adapts account-format compatibility from `security/crypto.py`; `launcher_native.py` adapts the launch arguments, region metadata, discovery and login sequence from `services/launcher.py` and `core/config.py`. The implementation is separated from the original GUI and external integrations. Local profile layout follows `app/main.py`. Author/project: xLordTime / Wiz Q Launcher. Original MIT notice: `bridge/launcher_web/WIZ_Q_LICENSE.txt`. No original account, configuration or log files are bundled.

## SpiralTracker (design reference only)

https://spiraltracker.com/ — UI/development credited by its credits page to HiitSayZ. Quest-overview concept used as inspiration. No verified open-source license was located; no source code, artwork, or complete quest-guide data from this site is redistributed. `bridge/quest_tracker.py` and `dist/quests.js` are independent implementations using local game data through the already credited DE-WizWalker.

## KIWAD format references

`bridge/sound_files.py` is an independent single-entry sound editor based on format descriptions in https://github.com/jonpalmisc/libkiwad/blob/master/SPEC.org and the read/pack layout in https://github.com/wizspoil/wizwad at `4f871ba2d66bfcf1f9c14dbae3173ab67a246c60`. No upstream implementation or game archive/audio is bundled. The `damage.wav` / `damage.ogg` preset is converted from the recording supplied by the MythicWalker project owner for this feature.

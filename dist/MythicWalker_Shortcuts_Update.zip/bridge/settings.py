"""Validated user configuration; no credentials or scripts are persisted here."""
import json
import math
import re
from pathlib import Path

ACTIONS = ('scan','hook','unhook','sync','freecam','run_script','stop','interact','forward')
DEFAULTS = {'global_hotkeys':False, 'poll_seconds':2, 'key_seconds':0.2,
            'bindings':{a:f'Ctrl+Alt+F{i+2}' for i,a in enumerate(ACTIONS)}}

def combo(value):
    if not isinstance(value,str): raise ValueError('Shortcut muss Text sein.')
    if not value.strip(): return ''
    parts=value.replace(' ','').upper().split('+')
    key=parts.pop()
    mods=set(parts)
    if len(mods)!=len(parts) or not mods or not mods <= {'CTRL','ALT','SHIFT'}:
        raise ValueError('Shortcut braucht Ctrl, Alt oder Shift; keine Windows-Taste.')
    if not re.fullmatch(r'[A-Z0-9]|F([1-9]|10|11)|SPACE|ENTER|ESC|TAB',key):
        raise ValueError('Taste nicht unterstützt (F12 ist reserviert).')
    return '+'.join([m.title() for m in ('CTRL','ALT','SHIFT') if m in mods]+[key])

def validate(data):
    if not isinstance(data,dict) or set(data) != set(DEFAULTS): raise ValueError('Ungültiges Settings-Format.')
    if type(data['global_hotkeys']) is not bool: raise ValueError('Global-Schalter muss boolesch sein.')
    result={'global_hotkeys':data['global_hotkeys']}
    for name,lo,hi in [('poll_seconds',0.5,10),('key_seconds',0.01,5)]:
        n=data[name]
        if type(n) not in (int,float) or not math.isfinite(n) or not lo<=n<=hi: raise ValueError(f'{name}: erlaubt sind {lo} bis {hi}.')
        result[name]=n
    bindings=data['bindings']
    if not isinstance(bindings,dict) or set(bindings)!=set(ACTIONS): raise ValueError('Ungültige Shortcut-Aktionen.')
    result['bindings']={a:combo(bindings[a]) for a in ACTIONS}
    used=[v for v in result['bindings'].values() if v]
    if len(used)!=len(set(used)): raise ValueError('Ein Shortcut darf nur einer Aktion zugewiesen sein.')
    return result

class Settings:
    def __init__(self,path=None):
        self.path=Path(path) if path else None
        self.data=validate(DEFAULTS)
        if self.path and self.path.exists():
            try: self.data=validate(json.loads(self.path.read_text(encoding='utf-8')))
            except (ValueError,OSError): pass
    def save(self,data):
        value=validate(data)
        if self.path:
            tmp=self.path.with_suffix('.tmp')
            tmp.write_text(json.dumps(value,indent=2),encoding='utf-8')
            tmp.replace(self.path)
        self.data=value
        return value

# Mythic Walker · Foundation v0.1.1

Ein eigener Wizard101-DE-Client mit moderner Weboberfläche und lokaler Windows-Bridge.

Dashboard: https://mythic-walker.lord-time.chatgpt.site

## Architektur und tatsächlicher Umfang

Die gehostete Oberfläche läuft online. WizWalker und die Memory-Hooks laufen **auf demselben Windows-PC wie Wizard101**. Ein normaler Browser und ein Cloud-Server können den Prozessspeicher deines PCs nicht direkt öffnen. Deshalb ist eine lokale Bridge zwingend nötig. Nach der einmaligen Einrichtung werden die implementierten Spielaktionen über die Weboberfläche bedient.

`HTTPS-Dashboard → WSS localhost:18761 → Python-Bridge → WizWalker → lokaler Spielprozess`

Die Verbindung bindet nur `127.0.0.1`; sie ist kein Fernzugriff über das Internet oder von einem Smartphone. Kein Port-Forwarding. Standardmäßig ist nur die oben genannte Site-Origin und die lokale Oberfläche erlaubt. Der bei jedem Start zufällig erzeugte Pairing-Code wird nicht im Browser gespeichert.

**Implementiert:**

- Client-Erkennung und Auswahl mehrerer Prozesse.
- Hook/Unhook über WizWalker, Timeout und Aufräumen bei Fehlern.
- Live-Daten: Position, Zone, HP, Mana, Level und Kampfstatus.
- XYZ-Teleport, Positions-Sync innerhalb derselben Zone und eindeutiger Entity-Teleport.
- Tasteneingaben, Freecam-Umschaltung und Kamerarücksetzung vor Unhook.
- Entity-Liste, UI-Fensterbaum, Klick auf ein eindeutiges sichtbares Fenster.
- Kampfkarten auslesen und manuell spielen: ohne Ziel/AoE, selbst oder erster lebender Gegner. Die Bridge prüft die Planungsphase.
- Validierter Skript-Runner mit Fortschritt und Stop; siehe Syntax unten.
- Browserlokale Skriptbibliothek und Wegpunkte, Skript- und Log-Export.
- Expliziter Demo-Modus ohne Spielzugriff, responsive Oberfläche und reduzierte Animationen nach Systempräferenz.

**Noch nicht integriert:** vollständiger Deimos-Parser, Blocks/Loops/closestmob, FriendTP, Playstyles, Auto-Quest, Auto-Combat, Fishing, Pet-Training und vollständige Raid-Module. Die Modul-Seite bezeichnet diese als spätere Erweiterungen. Andere Projekte sind Quellen und mögliche Adaptervorlagen, keine eingebauten Funktionen.

## Windows: starten

Voraussetzung: Windows 64-bit, Python 3.11–3.13 (64-bit, `py` verfügbar), Internet für die erste Installation und Wizard101 DE. Die Live-Bridge ist hier noch nicht gegen einen realen Windows-Spielprozess geprüft.

1. `MythicWalker_Starter.zip` entpacken.
2. PowerShell im entpackten Verzeichnis öffnen:

```powershell
powershell -ExecutionPolicy Bypass -File .\bridge\Setup.ps1
powershell -ExecutionPolicy Bypass -File .\bridge\Trust-Local-Bridge.ps1
```

`Setup.ps1` sucht gezielt CPython 3.13, 3.12 oder 3.11 (64-bit, Standard-Build). Python 3.14 wird für die Bridge nicht verwendet. Eine bereits angelegte unpassende `.venv` wird vor dem Neuerstellen unter `.venv-before-fix-…` gesichert. Anschließend installiert das Setup die Abhängigkeiten, prüft sie mit `pip check` und erzeugt ein lokales Zertifikat. Für `regex` werden ausschließlich fertige Wheels verwendet. `Trust-Local-Bridge.ps1` erklärt den Eintrag und fragt ausdrücklich nach `JA`, bevor **dieses lokale Zertifikat** in den Windows-Benutzer-Zertifikatsspeicher übernommen wird. Für die HTTPS-Webseite ist eine vertrauenswürdige WSS-Verbindung nötig. Administratorrechte sind für den Zertifikatseintrag in CurrentUser nicht vorgesehen.

3. `bridge\Start-Bridge.cmd` starten.
4. Wizard101 öffnen und mit deinem Charakter in der Welt einloggen.
5. Dashboard öffnen → **Bridge einrichten** → Pairing-Code aus dem Bridge-Fenster eingeben → **Verbindung herstellen**.
6. **Übersicht → Clients suchen → auswählen → Hooken**.

Die Bridge braucht ausreichend Windows-Prozessrechte. Läuft das Spiel erhöht, kann der Zugriff aus einem normalen Bridge-Prozess scheitern. Fehler werden angezeigt; Zugriffs- oder Pattern-Probleme werden nicht als erfolgreicher Hook ausgegeben.

### Setup schlägt mit regex / C++-Build-Tools fehl

Der ursprüngliche Installer konnte über `py -3` versehentlich Python 3.14 verwenden. Das korrigierte Setup wählt eine passende Version explizit aus. Installiere bei Bedarf Python 3.13 (64-bit, Standard-Build) zusätzlich, entpacke das aktualisierte Starterpaket und führe Setup erneut aus. Python 3.14 muss nicht deinstalliert werden. Die Trust-Skripte erst nach erfolgreichem Setup ausführen. Die PowerShell-Dateien sind jetzt als UTF-8 mit BOM gespeichert, damit Windows PowerShell 5.1 deutsche Zeichen richtig anzeigt.

### Windows-Fehler WinError 10054 / Proactor

Version 0.1.1 startet die lokale HTTPS/WSS-Bridge unter Windows explizit mit `SelectorEventLoop`. Damit wird der im ursprünglichen Log fehlschlagende Proactor-Aufräumcallback umgangen. Die Bridge benötigt keine asynchronen Windows-Pipes oder Subprocess-Transports. Andere Verbindungsfehler werden weiter angezeigt. Ein Browser kann die Verbindung weiterhin bei Zertifikats-, Berechtigungs- oder Pairing-Problemen ablehnen; die Ursache eines Reset ist durch den Traceback allein nicht bekannt. Nach erfolgreichem Pairing erscheint jetzt auch im Bridge-Fenster `Dashboard gekoppelt (LIVE).`.

### Falls die Verbindung nicht klappt

- Prüfe, dass das Bridge-Fenster offen ist.
- Öffne https://localhost:18761/health. Bei Zertifikatsfehlern Vertrauen einrichten und Browser neu starten.
- Falls Chrome/Edge nach lokalem Netzwerkzugriff fragt, erlaube ihn für diese Site.
- Die identische Oberfläche steht auch unter https://localhost:18761 bereit. Damit entfällt der Zugriff von einer gehosteten Origin auf localhost. Die Bridge und das Zertifikat bleiben erforderlich.
- Pro Bridge ist nur eine authentifizierte Dashboard-Sitzung möglich. Alte Sitzung trennen.
- Der Code ändert sich bei jedem Bridge-Start. Er wird nur im initialen WebSocket-Handshake gesendet.

Beim Trennen werden laufende Skripte gestoppt und Hooks entfernt. Beim Stoppen wird ein bereits laufender Memory-/Tastenschritt zunächst zu Ende geführt, damit Key-up und Patch-Abschluss nicht mitten im Schritt abgeschnitten werden. Warte maximal bis zum Schritt-Timeout (25 Sekunden). Beim normalen Beenden der Bridge mit Strg+C wird ebenfalls aufgeräumt. Erzwungenes Prozessbeenden kann dieses Aufräumen verhindern.

Vertrauen entfernen:

```powershell
powershell -ExecutionPolicy Bypass -File .\bridge\Remove-Local-Trust.ps1
```

### Eigene Windows-EXE bauen

```powershell
powershell -ExecutionPolicy Bypass -File .\bridge\Build-EXE.ps1
```

Das erzeugt `bridge\dist\MythicWalkerBridge.exe`. Es liegt **keine hier gebaute oder getestete Windows-EXE** bei. Der Build muss unter Windows erfolgen. Auf einem Ziel-PC zuerst `MythicWalkerBridge.exe --generate-cert` ausführen; das erzeugt `certs` neben der EXE. Kopiere die Trust-/Remove-Trust-Skripte ebenfalls in dieses Verzeichnis und führe das Trust-Skript dort aus. Danach die EXE normal starten. Private Schlüssel und `certs` nicht weitergeben.

## Skripte: unterstützter Teil der Deimos-Syntax

```text
# p1/p2 sind die Reihenfolge der ausgewählten Clients in der Oberfläche.
# completion wartet auf das Ende bereits laufender Kämpfe.
mass waitforcombat completion
sleep 0.5
mass sendkey W 0.2
sleep 3
p1 tp XYZ(100, 200, 0)
```

Unterstützt: `sleep`, `mass` bzw. `p1/p2/…`, `sendkey`, `tp XYZ(...)`, `waitforcombat completion`.
Grenzen: 200 Schritte, 16 KB Quelltext, Schlafen pro Schritt max. 60 Sekunden, Tastendauer 0.01–5 Sekunden, Kampfwartezeit max. 5 Minuten. Neue Schritte starten nicht mehr nach 15 Minuten Gesamtlaufzeit; die Prüfung erfolgt an Schrittgrenzen. Unbekannte Syntax wird vor Start zurückgewiesen. Es gibt kein `eval`, keine Python-Ausführung, keine freien Memory-Adressen und keinen Shell-Endpunkt.

Der Runner ist ein eigener kleiner Parser, **kein vollständiger Deimos-Ersatz**. Ein Syntax-Check kann nicht garantieren, dass ein Spielzustand oder ein Ziel zur Laufzeit verfügbar ist. Mehrclient-Aktionen laufen nacheinander; bei einem Fehler können vorherige Clients bereits bearbeitet sein.

Skripte und Wegpunkte werden pro Browser-Origin gespeichert, nicht serverseitig synchronisiert. Die Online- und lokale Oberfläche haben daher getrennte Browserdaten. Protokolle und Skripte lassen sich exportieren; Pairing-Codes werden nicht protokolliert.

## Backend & untersuchte Quellen

DE-Backend: [Vindaloniak/wizwalker](https://github.com/Vindaloniak/wizwalker), Branch `development`, Commit **13223e0911578e586975ace496d9f586ac4538da**, Commitdatum **14.09.2026**. Die Abhängigkeit ist auf diesen Commit fixiert; sie wird nicht bei jedem Start automatisch aktualisiert. Repo-Stand am 11.10.2026 abgefragt. „Aktueller GitHub-Stand“ bedeutet nicht, dass die Offsets mit jedem Spiel-Patch funktionieren.

[Deimos-Wizard101/wizwalker](https://github.com/Deimos-Wizard101/wizwalker) wurde als Upstream geprüft. Die Bridge nutzt die vorhandenen Client-/Hook-/Memory-Objekt-APIs, statt Offsets in JavaScript zu duplizieren.

Weitere gelesene READMEs:

- [Slackaduts/Deimos-Wizard101](https://github.com/Slackaduts/Deimos-Wizard101): verweist auf die neue Deimos-Organisation.
- [CIick/FishyBusiness](https://github.com/CIick/FishyBusiness): konfigurierbares Fishing auf WizWalker.
- [Lxghtend/raid-utility-tools](https://github.com/Lxghtend/raid-utility-tools): Raid-Hilfen, Hook-Verwaltung, Clientdaten und Teleports.
- [StarrFox/wizdancer](https://github.com/StarrFox/wizdancer): Dance-/Pet-Training.
- [LaurenzLikeThat/wiztype](https://github.com/LaurenzLikeThat/wiztype): Type-Dumps und Offset-Diagnose.
- [Slackaduts/wizdiff](https://github.com/Slackaduts/wizdiff): Spielversions-Vergleiche.
- [vbe0201/wizproxy](https://github.com/vbe0201/wizproxy): separates Packet-Proxy-Projekt, keine Integration in diese Bridge.

Die im Suchlauf gefundenen Forks von nboj, notfaj und 7e11 sind in `sources.json` verlinkt. Deren vollständiger Quellcode wurde nicht umfassend geprüft. In dieser Version ist nur WizWalker eine eingebundene Spielbibliothek.

## Entwicklerstruktur

- `dist/`: buildlose Online-Oberfläche.
- `bridge/server.py`: TLS, Pairing, Protokoll, Runner und Sitzungslebenszyklus.
- `bridge/adapter.py`: realer WizWalker-Adapter und eigenständiger Demo-Adapter.
- `bridge/protocol.py`: Validierung und Skriptparser ohne Spielabhängigkeit.
- `bridge/web/`: Kopie der Oberfläche für den Starter und EXE-Build.
- `tests/`: Bridge- und Protokollprüfungen.

Live-Origin ändern: `server.py --origin https://deine-domain.example` (kein abschließender Slash). Standard bleibt die hier veröffentlichte Site.

## Verifikation

```text
python -m unittest discover -s tests -v
node tests/test_frontend.cjs
node --check dist/app.js
```

Geprüft: echte TLS-WebSocket-Verbindungen mit Demo-Adapter, Origin- und Token-Abweisung, Einzelsitzung, Hook-Failure-Aufräumen mit einem Mock-Client, Skriptvalidierung, Stop, Ende laufender Schritte, Disconnect-Unhook, private Dateiabschirmung, lokale Assets und Zertifikatsvalidierung; JavaScript-Parser, HTML-Escaping und DOM-ID-Verträge.

Nicht geprüft: echter Wizard101-DE-Prozess unter Windows, Spielfunktionen im Livebetrieb, Windows-EXE-Build und gerenderte Browserdarstellung. Diese Einschränkungen gelten auch für die als „implementiert“ bezeichneten Live-Adapter.

## Lizenz

GPL-3.0-or-later. Siehe `LICENSE` und `THIRD_PARTY_NOTICES.md`. WizWalker wird als Abhängigkeit installiert; sein Quellcode ist unter dem fixierten Commit verfügbar. Das Starterpaket enthält den vollständigen Quellcode dieses Grundgerüsts.

## Version 0.2.0: Shortcuts und Einstellungen

Im Dashboard unter **Einstellungen** kannst du Shortcuts frei eingeben oder aufnehmen,
Tastendauer (0,01–5 Sekunden) und Status-Intervall (0,5–10 Sekunden) bearbeiten.
Ein leeres Shortcut-Feld deaktiviert die Aktion. Doppelte Kombinationen werden abgelehnt.
Anzeigeoptionen: drei Akzentfarben, kompakte Darstellung, reduzierte Animationen,
Erfolgs-Benachrichtigungen und 50–1000 Protokoll-Einträge. Import/Export ist als JSON möglich.
Änderungen mit **Änderungen speichern** übernehmen. Der Browser behält die Einstellungen
und überträgt seine Steuerungskonfiguration bei jeder Kopplung an die Bridge.
Die Bridge speichert diese in `bridge/user-settings.json` (bei EXE neben der EXE).
Pairing-Code, Client-Auswahl und Skript-Inhalt werden dort nicht gespeichert.

| Standard-Shortcut | Aktion |
|---|---|
| Ctrl+Alt+F2 | Clients suchen |
| Ctrl+Alt+F3 | Auswahl hooken |
| Ctrl+Alt+F4 | Auswahl unhooken |
| Ctrl+Alt+F5 | Position zum ersten ausgewählten Client synchronisieren |
| Ctrl+Alt+F6 | Freecam umschalten |
| Ctrl+Alt+F7 | Aktuellen Skript-Editor starten |
| Ctrl+Alt+F8 | Skript stoppen |
| Ctrl+Alt+F9 | X senden |
| Ctrl+Alt+F10 | W senden |

Im Browser sind die Shortcuts sofort verfügbar (außer beim Bearbeiten von Eingabefeldern
und in geöffneten Dialogen). **Shortcuts auch im Spiel** aktiviert Windows-RegisterHotKey:
Die Kombinationen funktionieren systemweit, während das Dashboard gekoppelt ist, auch
bei fokussiertem Wizard101. Sie verwenden die im Dashboard ausgewählten Clients.
Das Skript verwendet den aktuellen Editor-Inhalt, einschließlich ungespeicherter Änderungen.
Belegte Tastenkombinationen erscheinen im Shortcut-Status; im fokussierten Dashboard gibt
es dafür einen Browser-Fallback. Beim Aufnehmen werden globale Shortcuts kurz pausiert.
Beim Trennen werden sie abgemeldet. F12 und die Windows-Taste sind nicht verfügbar.

**Update einer bestehenden Installation:** Bridge stoppen, `MythicWalker_Shortcuts_Update.zip`
in den bisherigen Starter-Ordner entpacken und Dateien überschreiben. `.venv`, Zertifikate
und vorhandene lokale Einstellungen bleiben erhalten. `bridge\Start-Bridge.cmd` erneut
starten und Dashboard mit Strg+F5 neu laden. Keine erneute Installation nötig.
